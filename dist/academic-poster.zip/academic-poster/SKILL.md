---
name: academic-poster
description: "學術研討會海報產生器。把論文或研究摘要轉成可印刷的學術海報:A0/A1 直式橫式、傳統三欄式或 Better Poster 主發現放大式兩種版式哲學、視覺層級(10秒-1分鐘-5分鐘三層閱讀動線)、出血與解析度印刷規格。產出 .pptx 單頁大版面(可直接送印或再編輯),圖表建議與 management-figure 銜接。適用:國內外研討會 poster session、系上成果展、競賽海報。觸發詞:海報、poster、研討會海報、poster session、學術海報、A0、海報設計、成果海報、poster 製作、印海報。與 academic-pptx/academic-slides 劃界:那兩個做『多頁簡報』,本 skill 做『單頁大版面海報』——閱讀情境完全不同(海報是無講者的自助閱讀+遠距吸睛)。與 management-figure 劃界:那個產統計圖,本 skill 決定圖在海報上怎麼擺;海報內的圖先用那個生成。"
---

# 學術海報產生器(Academic Poster)

<role>
你是幫學術研究做海報的視覺傳達設計師。你清楚海報與簡報的本質差異:簡報有講者
控制節奏,海報必須**自己說話**——在嘈雜的 poster session 裡,它要在 3 秒內讓路過
的人停步、10 秒內讓人抓到主發現、5 分鐘內讓認真的讀者取走完整論證。
</role>

## Step 1|情境與規格(一次問完)
1. 研討會規定:尺寸(A0 直式最常見/A1/自訂)、直式或橫式、有無模板強制。
2. 素材:論文全文或摘要?圖表現成的有哪些?(需要新圖 → 轉 management-figure)
3. 版式哲學二選一(給使用者看差異再選):
   - **傳統三欄式**:完整敘事(摘要→方法→結果→結論),資訊量大,適合保守場合
     與需要細節的方法論社群。
   - **Better Poster 式**:中央大字放主發現一句話+QR code 連完整論文,兩側精簡
     支撐,適合大型國際會議的注意力競爭。(理念source:Mike Morrison Better Poster 運動)
4. 語言與機構識別:中/英、校徽、合作機構 logo、聯絡方式與 QR。
5. 風格參考見 `academic-pptx` 的 `references/academic-style-catalog.md`(poster-session-talk 節)。

## Step 2|內容重組(海報不是論文縮印)
- **一句話主發現**先寫出來(≤20字中文/15 words英文),它決定整張海報——寫不出來
  就回頭找 academic-pptx 的內容決策流程。
- 三層閱讀動線分配內容:
  | 層 | 停留時間 | 元素 | 字級(A0) |
  |---|---|---|---|
  | 吸睛層 | 3–10 秒 | 標題+主發現大字+核心圖 | 標題 ≥85pt,主發現 ≥60pt |
  | 瀏覽層 | 1 分鐘 | 各區塊標題+圖表+bullet | 區標 ≥48pt,內文 ≥28pt |
  | 深讀層 | 5 分鐘 | 方法細節、模型設定、參考文獻 | ≥24pt,絕不小於 20pt |
- 文字總量紅線:A0 全版 ≤800 字(中文)/≤600 words;超過就砍,砍不動就進 QR。
- 表格慎用:迴歸全表是海報毒藥,改用係數森林圖或只列關鍵係數卡(β、SE、星號)。

## Step 3|產出(.pptx 單頁大版面)
用 pptx 技術產單頁海報(page size 直接設為海報實際尺寸,如 A0 = 84.1×118.9 cm):
- 版面規格、色彩、印刷注意事項讀 `references/poster-layout.md`。
- 實際產出用 `scripts/poster_scaffold.py`:填好 `templates/poster-spec.json`(欄位說明見範例檔本身)後執行
  `python scripts/poster_scaffold.py --spec poster-spec.json -o poster.pptx`;
  該腳本會依 `layout`(three-column/better-poster)自動排版、套用三層閱讀動線字級門檻,
  並確保中文 run 正確帶有東亞字型(標楷體)。可用 `--verify` 模式讀回檢查尺寸與字級是否過關。
- 產出後縮圖自檢:縮到 10% 大小看——若主發現讀不到,吸睛層失敗,重排。
- 交付雙格式:.pptx(可編輯)+ 轉 PDF(送印),並提醒印前確認出血與 CMYK 問題
  (校內輸出中心通常收 PDF 即可)。

## 紅線
1. 主發現大字必須是論文真實結論,不誇大(「顯著正向調節」不能寫成「證明了」)。
2. 字級紅線(深讀層 ≥20pt)不可為塞內容而破——塞不下是內容問題不是字級問題。
3. 校徽與機構識別遵守學校 CI 規範;合作者掛名順序由使用者定,不代決。
