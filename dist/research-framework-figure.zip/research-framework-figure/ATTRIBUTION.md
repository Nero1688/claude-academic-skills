# 來源標示 (Attribution)

## 借用的設計模式（非程式碼）

### hugohe3/ppt-master — SVG 作為中介表示法的轉換管線

`scripts/svg2drawingml.py`（2026-08-14 新增）的**設計模式**參考自
[hugohe3/ppt-master](https://github.com/hugohe3/ppt-master)（MIT License）。

**借鑑了什麼**（三個具體觀念，非程式碼）：

1. **以 SVG 為中介表示法，再機械式確定性轉成 DrawingML**——而不是讓程式逐一
   硬寫 python-pptx 呼叫。SVG 好產生、好預覽、好除錯，轉換規則則可以是純函式。
2. **「預設留白、按需材質化」的分層原則**——文字預設走零依賴的直接
   `<p:txBody>` XML 產生，保持在 PowerPoint 內可點選編輯；只有在需要
   「文字與形狀做布林合成」這種 DrawingML 原生做不到的窄用途時，
   才犧牲可編輯性去做字形外框化。本技能的學術圖形用不到後者，故只實作前者。
3. **白名單驗證哲學：絕不靜默劣化**——遇到不支援的 SVG 元素就明確回報，
   不做視覺近似、也不偷偷退化成點陣圖。這一點比技術實作本身更重要：
   本技能先前的 PPTX 匯出正是因為「產檔不報錯但內容不全」而靜默丟失了所有箭頭。

**未借用什麼**：
- **未複製任何原始碼**。`svg2drawingml.py` 為自行實作，路徑正規化（Q→C 的 2/3
  控制點內插、A→C 的 SVG 規格 F.6.5 端點→圓心參數化）依公開規格自行撰寫。
- **刻意不引入 `skia-pathops` 與 `uharfbuzz`**。這兩者在 ppt-master 中分別只服務
  「形狀布林運算」與「文字作為布林操作元」，學術架構圖用不到；為此引入兩個
  綁定 C 擴充的大型相依不划算。本模組維持**零額外相依**（SVG 輸出仍為純標準庫，
  PPTX 輸出僅需既有的 python-pptx）。
- 未採用其內容產生層（LLM 生簡報的工作流）——該部分與本家族既有的
  `academic-pptx`／`academic-deck-animator` 重複，且其定位為通用商業簡報，
  不含學術論證嚴謹性的把關。

謹此致謝 Hugo He 與 ppt-master 貢獻者：該專案證明了「支援複雜向量圖形」與
「保留原生可編輯性」並不衝突，這個洞見直接促成本技能修復了一個
會靜默丟失全部箭頭的缺陷。

## 借用的程式碼

**無。** `scripts/framework_figure.py` 與 `scripts/svg2drawingml.py` 均為自行撰寫。

建置前曾在 GitHub 盤點既有方案，結論是**這個需求沒有現成工具**：
- `semPlot`（R）、`lavaanPlot`（R）畫的是**已配適模型的路徑圖（帶係數）**，
  與本技能要的「尚未跑資料的概念性架構圖」用途不同。
- `excalidraw-diagram-skill`、`diagram-design` 等是通用繪圖技能，
  非為中介／調節模型設計；且前者未標示授權，不可抄用。
- Graphviz DOT、TikZ、`pptx-shapes` 屬通用繪圖手法，本技能未使用其程式碼
  （SVG 由標準庫字串直接組出，不依賴任何繪圖函式庫）。

**因此本技能未借用他人程式碼。** 上述專案僅在評估階段被列入比較，未閱讀或複製其實作。

### diagram-design — 視覺紀律概念（`references/visual-discipline.md`）

`references/visual-discipline.md`（2026-09-20 新增，與 `management-figure`
共用）的密度上限、單一強調色、節點存在理由、對齊網格等判準，借用自
`diagram-design` 技能的視覺紀律精神。授權：MIT License。

**借用了什麼**：無陰影無漸層、密度控制（節點數／連線數上限）、單一強調色
搭配中性色、「每個節點要有存在理由」的取捨判準、對齊網格等**概念**，改寫
為研究圖表（架構圖／樣本流程圖）適用的版本。

**未借用什麼**：**未借用程式碼**。`references/visual-discipline.md` 為
自行撰寫的規範文件，不含任何程式邏輯；`framework_figure.py` 的排版與繪圖
程式碼與 `diagram-design` 無關、獨立實作。

### frontend-design — 先定調再產出的流程概念

`references/visual-discipline.md`「畫圖前先回答三個問題」一節，借用自
`frontend-design` 技能「先定調再產出」的工作流程精神。授權：Apache License
2.0。

**借用了什麼**：產出前先確立目的與情境（讀者要在多短時間內看懂什麼、產出
物要用在哪個情境）的**流程概念**，改寫為學術圖表適用的三個問題（5 秒訊息、
放進論文哪一節、黑白可讀性）。

**未借用什麼**：**未借用程式碼**。本技能未使用 `frontend-design` 的任何
實作或範本，僅借用其「先確立情境與目的，再動手產出」的流程順序。

## 相依套件

| 套件 | 授權 | 用途 |
|---|---|---|
| （SVG 輸出） | — | **零依賴**，僅使用 Python 標準庫 |
| `python-pptx` | MIT | 選用——僅在匯出 PPTX 時需要，以 pip 正常安裝使用，未修改其原始碼 |

## 學術繪圖慣例的出處

`references/diagram-conventions.md` 所載的畫法規範（調節箭頭指向路徑中點、
中介與調節的線型區別、被調節的中介需標明階段等）屬**學科通行慣例**，
非特定專案之著作，故無需授權標示。使用者若要在論文中引用這些規範的權威來源，
建議查閱 Baron & Kenny (1986)、Hayes 的 PROCESS 相關著作等原始文獻——
**本技能不代為宣稱這些慣例的確切出處，請自行查證後引用**。

本技能供學術研究使用。
